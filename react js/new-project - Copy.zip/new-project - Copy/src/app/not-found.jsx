import React from 'react'

export default function notFound() {
  return (
    <div>
        page not found      
    </div>
  )
}
