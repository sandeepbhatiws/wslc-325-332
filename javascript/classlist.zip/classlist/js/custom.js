function removeClass(){
    document.getElementById('content').classList.add('display');
}

function addClass(){
    document.getElementById('content').classList.remove('display');
}

function toogleClass(){
    document.getElementById('content').classList.toggle('display');
}